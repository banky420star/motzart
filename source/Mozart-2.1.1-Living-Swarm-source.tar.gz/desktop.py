from __future__ import annotations

import json
import base64
import os
import socket
import subprocess
import threading
import time
import urllib.request
import webbrowser
import html
import traceback
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
APP_VERSION = (ROOT / "VERSION").read_text().strip() if (ROOT / "VERSION").exists() else "1.1.7"

# Native builds keep user-owned state outside the .app bundle so Mozart remains
# portable when moved into /Applications or ~/Applications.
if os.uname().sysname == "Darwin":
    APP_SUPPORT = Path.home() / "Library" / "Application Support" / "Mozart"
else:
    APP_SUPPORT = ROOT
APP_SUPPORT.mkdir(parents=True, exist_ok=True)

# User settings override packaged defaults. The package .env remains useful for
# browser/developer mode, while the Application Support file follows the app.
load_dotenv(ROOT / ".env", override=False)
load_dotenv(APP_SUPPORT / ".env", override=False)
os.environ.setdefault("MOZART_HOST", "127.0.0.1")
os.environ.setdefault("MOZART_PORT", "8765")
os.environ.setdefault("MOZART_DATA_DIR", str(APP_SUPPORT / "data"))
os.environ.setdefault("MOZART_WORKSPACE", str(APP_SUPPORT / "workspace"))


def _health_payload(port: int, timeout: float = 0.35):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ready", timeout=timeout) as response:
            if not (200 <= response.status < 300):
                return None
            return json.loads(response.read().decode("utf-8"))
    except Exception:
        return None


def _port_is_bound(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.15)
        return sock.connect_ex(("127.0.0.1", port)) == 0


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _resolve_runtime_port() -> int:
    requested = int(os.getenv("MOZART_PORT", "8765"))
    payload = _health_payload(requested)
    if payload and payload.get("product") == "Mozart" and str(payload.get("version")) == APP_VERSION:
        return requested
    if payload is not None or _port_is_bound(requested):
        requested = _free_port()
        os.environ["MOZART_PORT"] = str(requested)
    return requested


RUNTIME_PORT = _resolve_runtime_port()
os.environ["MOZART_PORT"] = str(RUNTIME_PORT)

import uvicorn

from backend.main import app, settings

try:
    import webview
except Exception as exc:  # pragma: no cover - platform dependent
    webview = None
    WEBVIEW_IMPORT_ERROR = exc
else:
    WEBVIEW_IMPORT_ERROR = None


# The launch experience must use the same source-of-truth brand mark as the
# application chrome and app icon. It is embedded as a data URI so it renders
# before the local HTTP server is available.
_BRAND_MARK = ROOT / "backend" / "static" / "brand" / "mozart-mark.svg"
_BRAND_MARK_DATA = base64.b64encode(_BRAND_MARK.read_bytes()).decode("ascii")
_BRAND_MARK_URI = f"data:image/svg+xml;base64,{_BRAND_MARK_DATA}"


LOADING_HTML = f"""<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>
*{{box-sizing:border-box}}html,body{{margin:0;width:100%;height:100%;overflow:hidden;background:#07131d;color:#f2eee6;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","Segoe UI",sans-serif}}
body{{display:grid;place-items:center;background:radial-gradient(circle at 50% 43%,rgba(46,196,182,.10),transparent 26%),radial-gradient(circle at 58% 48%,rgba(255,142,115,.055),transparent 20%),linear-gradient(180deg,#081722,#06111a)}}
.boot{{width:min(560px,84vw);text-align:center}}
.logo-wrap{{position:relative;width:148px;height:148px;margin:0 auto 28px;display:grid;place-items:center}}
.logo-halo{{position:absolute;inset:13px;border-radius:42%;background:radial-gradient(circle,rgba(46,196,182,.12),rgba(46,196,182,0) 68%);filter:blur(8px);animation:halo 3.2s ease-in-out infinite}}
.brand-mark{{position:relative;width:132px;height:132px;display:block;filter:drop-shadow(0 22px 42px rgba(0,0,0,.28));animation:brandBreathe 3.2s cubic-bezier(.4,0,.2,1) infinite;transform-origin:50% 54%}}
h1{{margin:0;font-size:36px;letter-spacing:-.055em;font-weight:760}}
p{{margin:7px 0 0;color:#95aaa6;font-size:11px;letter-spacing:.19em;text-transform:uppercase;font-weight:620}}
.status{{margin:34px auto 0;width:min(310px,76vw);height:3px;border-radius:99px;background:rgba(255,255,255,.07);overflow:hidden}}
.status i{{display:block;width:38%;height:100%;border-radius:inherit;background:linear-gradient(90deg,#2ec4b6,#8ee3d7,#ff8e73,#ffd6b6);animation:load 1.45s cubic-bezier(.65,0,.35,1) infinite}}
.caption{{margin-top:12px;color:#69827f;font-size:10px;letter-spacing:0;text-transform:none;font-weight:500}}
@keyframes brandBreathe{{0%,100%{{transform:scale(.985) rotate(-.35deg)}}50%{{transform:scale(1.025) rotate(.35deg)}}}}
@keyframes halo{{0%,100%{{transform:scale(.92);opacity:.46}}50%{{transform:scale(1.08);opacity:.85}}}}
@keyframes load{{0%{{transform:translateX(-115%)}}100%{{transform:translateX(365%)}}}}
@media (prefers-reduced-motion:reduce){{.brand-mark,.logo-halo,.status i{{animation:none}}.status i{{width:68%}}}}
</style></head><body><main class="boot"><div class="logo-wrap"><span class="logo-halo"></span><img class="brand-mark" src="{_BRAND_MARK_URI}" alt="Mozart"></div><h1>MOZART</h1><p>Autonomous Software Intelligence</p><div class="tagline">Intelligence in motion.</div><div class="status"><i></i></div><div class="caption" id="bootCaption">Waking the local workforce…</div></main></body></html>"""


class DesktopBridge:
    def __init__(self) -> None:
        self.window = None

    def choose_workspace(self):
        if self.window is None or webview is None:
            return None
        result = self.window.create_file_dialog(webview.FileDialog.FOLDER, directory=str(settings.workspace))
        return result[0] if result else None

    def reveal_workspace(self):
        path = str(settings.workspace)
        try:
            if os.uname().sysname == "Darwin":
                subprocess.Popen(["open", path])
                return True
        except Exception:
            pass
        return False

    def quit_app(self):
        if self.window is not None:
            try:
                self.window.destroy()
                return True
            except Exception:
                return False
        return False

    def app_info(self):
        return {
            "name": "Mozart",
            "subtitle": "Autonomous Software Intelligence",
            "workspace": str(settings.workspace),
            "version": getattr(app, "version", APP_VERSION),
            "app_support": str(APP_SUPPORT),
        }


def endpoint_ready(url: str, timeout: float = 0.6) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            if not (200 <= response.status < 300):
                return False
            payload = json.loads(response.read().decode("utf-8"))
            return payload.get("product") == "Mozart" and str(payload.get("version")) == APP_VERSION
    except Exception:
        return False


def start_server() -> tuple[uvicorn.Server | None, threading.Thread | None]:
    host = "127.0.0.1"
    port = int(os.getenv("MOZART_PORT", "8765"))
    health = f"http://{host}:{port}/api/ready"
    if endpoint_ready(health):
        return None, None

    config = uvicorn.Config(app, host=host, port=port, log_level="warning", access_log=False)
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, name="mozart-local-runtime", daemon=True)
    thread.start()
    deadline = time.time() + 30
    while time.time() < deadline:
        if endpoint_ready(health):
            return server, thread
        if not thread.is_alive():
            raise RuntimeError("Mozart local runtime stopped during startup")
        time.sleep(0.12)
    raise RuntimeError("Mozart local runtime did not become ready")


def _browser_fallback(url: str, server: uvicorn.Server | None, thread: threading.Thread | None) -> None:
    # A native Cocoa failure must never look like a dead app. Keep the local
    # runtime alive and open the same complete UI in the default browser.
    webbrowser.open(url)
    try:
        if thread is not None:
            while thread.is_alive():
                time.sleep(0.4)
        else:
            while endpoint_ready(f"{url}/api/ready", timeout=0.8):
                time.sleep(1.0)
    except KeyboardInterrupt:
        pass
    finally:
        if server is not None:
            server.should_exit = True


MIN_BRAND_SECONDS = 4.6
BRAND_READY_HOLD_SECONDS = 0.45


def main() -> None:
    port = int(os.getenv("MOZART_PORT", "8765"))
    url = f"http://127.0.0.1:{port}"

    if webview is None:
        server, thread = start_server()
        print(f"Native pywebview unavailable: {WEBVIEW_IMPORT_ERROR!r}", flush=True)
        _browser_fallback(url, server, thread)
        return

    bridge = DesktopBridge()
    runtime: dict[str, object | None] = {"server": None, "thread": None}
    window = webview.create_window(
        "Mozart — Autonomous Software Intelligence",
        html=LOADING_HTML,
        js_api=bridge,
        width=1460,
        height=940,
        min_size=(760, 560),
        background_color="#06131f",
        text_select=True,
        confirm_close=False,
    )
    bridge.window = window

    def bootstrap_runtime() -> None:
        visible_started = time.monotonic()
        transitioned = threading.Event()

        def set_boot_caption(message: str) -> None:
            if transitioned.is_set():
                return
            try:
                window.evaluate_js(
                    "document.getElementById('bootCaption').textContent=" + json.dumps(message)
                )
            except Exception:
                pass

        def brand_sequence() -> None:
            # The launch screen is intentionally a brand moment. These stages
            # run independently from backend speed so a fast Mac does not make
            # the Mozart identity flash past before it can be perceived.
            stages = (
                (1.15, "Connecting local intelligence…"),
                (2.35, "Restoring workspace and memory…"),
                (3.55, "Assembling the living workforce…"),
            )
            for at_second, caption in stages:
                remaining = visible_started + at_second - time.monotonic()
                if remaining > 0:
                    time.sleep(remaining)
                if transitioned.is_set():
                    return
                set_boot_caption(caption)

        threading.Thread(target=brand_sequence, name="mozart-brand-sequence", daemon=True).start()
        try:
            server, thread = start_server()
            runtime["server"], runtime["thread"] = server, thread
            # Even when the backend is ready instantly, preserve enough time
            # for the user to actually read the mark, lockup and launch copy.
            remaining = visible_started + MIN_BRAND_SECONDS - time.monotonic()
            if remaining > 0:
                time.sleep(remaining)
            set_boot_caption("Mozart is ready.")
            time.sleep(BRAND_READY_HOLD_SECONDS)
            transitioned.set()
            window.load_url(url + "?native=1")
        except Exception as exc:
            message = html.escape(str(exc))
            window.load_html(
                LOADING_HTML.replace(
                    "Waking the local workforce…",
                    f"Startup failed: {message}. Close Mozart and check ~/Library/Logs/Mozart/launcher.log",
                )
            )

    gui = os.getenv("MOZART_WEBVIEW_GUI") or None
    try:
        # Show the branded native window immediately. Cocoa is preferred on
        # macOS; the launcher may select Qt when PyObjC cannot load.
        webview.start(bootstrap_runtime, gui=gui, debug=False)
    except Exception as exc:
        # A renderer failure must not make Mozart look dead. Log the exact
        # failure and keep the complete product usable in the default browser.
        print(f"Native webview renderer failed ({gui or 'cocoa'}): {exc!r}", flush=True)
        server = runtime.get("server")
        thread = runtime.get("thread")
        if server is None and thread is None:
            server, thread = start_server()
            runtime["server"], runtime["thread"] = server, thread
        _browser_fallback(url, server, thread)
    finally:
        server = runtime.get("server")
        if server is not None:
            server.should_exit = True


def run_with_crash_recovery() -> None:
    try:
        main()
    except Exception as exc:
        log_dir = Path.home() / "Library" / "Logs" / "Mozart"
        log_dir.mkdir(parents=True, exist_ok=True)
        report = log_dir / "crash-report.log"
        report.write_text(
            f"Mozart {APP_VERSION} fatal startup error\n\n{traceback.format_exc()}",
            encoding="utf-8",
        )
        message = f"Mozart recovered from a startup failure.\n\n{exc}\n\nReport: {report}"
        try:
            subprocess.run(
                ["/usr/bin/osascript", "-e", "on run argv", "-e",
                 'display dialog (item 1 of argv) buttons {"OK"} with title "Mozart" with icon caution',
                 "-e", "end run", "--", message],
                check=False, timeout=10,
            )
        except Exception:
            pass
        raise


if __name__ == "__main__":
    run_with_crash_recovery()
